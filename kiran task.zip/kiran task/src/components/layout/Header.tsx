"use client";

import React from "react";

import {
  Box,
  Flex,
  HStack,
  Text,
  Button
} from "@chakra-ui/react";

export default function Header() {

  return (
    <Box as="header" bg="white" boxShadow="sm" w="100%">
      <Flex
        maxW="1100px"
        mx="auto"
        py={4}
        px={2}
        align="center"
        justify="space-between"
      >
        <HStack gap={3} align="center">
          <Box w="50px" h="45px" borderRadius="8px" overflow="hidden">
            <h1>put img here</h1>
          </Box>
          <Text fontWeight={700}>MPKV Student Portal</Text>
        </HStack>

        <HStack gap={4}>
          {/* LOGIN BUTTON */}
          <Button
            variant="ghost"
            color="gray.600"
            borderRadius="full"
            px={6}
            onClick={() => (window.location.href = "/auth/login")}
          >
            Login
          </Button>

          {/* REGISTER BUTTON */}
          <Button
            bg="var(--brand-500)"
            color="white"
            _hover={{ bg: "var(--brand-700)" }}
            borderRadius="full"
            px={6}
            onClick={() => (window.location.href = "/auth/signup")}
          >
            Register
          </Button>
        </HStack>
      </Flex>
    </Box>
  );
}
